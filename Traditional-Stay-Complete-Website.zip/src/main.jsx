import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { jsPDF } from "jspdf";
import "./styles.css";

const PROPERTY = {
  name: "SPOT ON Traditional Stay",
  address:
    "Plot no.- 3-178, Road Number 4, Ganesh Nagar, Gandimaisamma, Madchal, Hyderabad, 500043, India",
  landmark: "Near Snak Hub / New Baba Building",
  coords: { lat: 17.57483, lng: 78.4209672 },
  category: "2-star budget hotel",
  rating: 4.3,
  ratingCount: 3,
  alternateRating: 4.7,
  alternateRatingCount: 4,
  checkIn: "12:00 PM",
  checkOut: "11:00 AM",
  room: {
    name: "Classic Room",
    capacity: 3,
    size: "97 sq.ft (9 sq.mt)",
    bed: "1 Queen Bed",
    price: 1201,
    tax: 140,
    features: [
      "Air conditioning",
      "Free Wi-Fi",
      "Flat-screen TV",
      "Private bathroom",
      "Room service",
      "Housekeeping",
      "Mineral water"
    ]
  },
  amenities: [
    "Free Wi-Fi",
    "Room service",
    "Family rooms",
    "24-hour front desk",
    "Air conditioning",
    "Flat-screen TV",
    "Private bathroom",
    "Seating area",
    "Desk",
    "Housekeeping"
  ]
};

const seedReviews = [
  {
    source: "OYO listing",
    rating: PROPERTY.rating,
    text: "The OYO listing currently shows a Very Good guest rating.",
    note: "3 ratings"
  },
  {
    source: "OYO listing",
    rating: PROPERTY.alternateRating,
    text: "Another current OYO listing snapshot shows an Excellent rating.",
    note: "4 ratings"
  },
  {
    source: "Google Maps",
    rating: null,
    text: "Live Google review text could not be reliably extracted from the supplied Maps short link, so no review text is fabricated here.",
    note: "Source-linked"
  }
];

function money(n) {
  return `₹${Math.round(n).toLocaleString("en-IN")}`;
}

function makeBookingId() {
  return `TS${Date.now().toString().slice(-8)}`;
}

function App() {
  const [page, setPage] = useState("home");
  const [booking, setBooking] = useState(null);
  const [auth, setAuth] = useState(() => localStorage.getItem("ts_user") || "");
  const [authMode, setAuthMode] = useState("register");
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    password: ""
  });

  const [search, setSearch] = useState({
    checkIn: "",
    checkOut: "",
    guests: 1
  });

  const [guestForm, setGuestForm] = useState({
    name: "",
    email: "",
    phone: "",
    guests: 1
  });

  const total = useMemo(() => {
    const base = PROPERTY.room.price;
    const taxes = PROPERTY.room.tax;
    return base + taxes;
  }, []);

  function go(p) {
    setPage(p);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function openBooking() {
    if (!search.checkIn || !search.checkOut) {
      alert("Select check-in and check-out dates first.");
      return;
    }
    if (new Date(search.checkOut) <= new Date(search.checkIn)) {
      alert("Check-out must be after check-in.");
      return;
    }
    setGuestForm((x) => ({ ...x, guests: search.guests }));
    go("book");
  }

  function saveUser(e) {
    e.preventDefault();
    if (!form.name || !form.email || !form.phone || !form.password) {
      alert("Please complete all fields.");
      return;
    }
    localStorage.setItem("ts_user", form.email);
    localStorage.setItem("ts_user_name", form.name);
    setAuth(form.email);
    alert("Account created locally for this demo.");
    go("home");
  }

  function createBooking(e) {
    e.preventDefault();
    if (!guestForm.name || !guestForm.email || !guestForm.phone) {
      alert("Please enter guest details.");
      return;
    }

    const record = {
      id: makeBookingId(),
      property: PROPERTY.name,
      address: PROPERTY.address,
      room: PROPERTY.room.name,
      checkIn: search.checkIn,
      checkOut: search.checkOut,
      guests: Number(guestForm.guests),
      guest: guestForm,
      roomAmount: PROPERTY.room.price,
      taxes: PROPERTY.room.tax,
      total,
      status: "Pending payment",
      createdAt: new Date().toISOString()
    };

    setBooking(record);
    localStorage.setItem("ts_booking", JSON.stringify(record));
    go("payment");
  }

  async function pay() {
    if (!booking) return;

    const apiBase = import.meta.env.VITE_API_BASE || "http://localhost:5000";
    try {
      const response = await fetch(`${apiBase}/api/create-order`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: booking.total, bookingId: booking.id })
      });

      if (!response.ok) throw new Error("Razorpay backend is not configured.");

      const order = await response.json();
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => {
        const options = {
          key: import.meta.env.VITE_RAZORPAY_KEY_ID,
          amount: order.amount,
          currency: order.currency,
          name: PROPERTY.name,
          description: booking.room,
          order_id: order.id,
          prefill: {
            name: booking.guest.name,
            email: booking.guest.email,
            contact: booking.guest.phone
          },
          theme: { color: "#111827" },
          handler: async (result) => {
            const verify = await fetch(`${apiBase}/api/verify-payment`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(result)
            });
            const verified = await verify.json();

            if (verified.valid) {
              const paid = {
                ...booking,
                status: "Paid",
                paymentId: result.razorpay_payment_id,
                orderId: result.razorpay_order_id
              };
              setBooking(paid);
              localStorage.setItem("ts_booking", JSON.stringify(paid));
              go("confirmation");
            } else {
              alert("Payment signature verification failed.");
            }
          }
        };
        new window.Razorpay(options).open();
      };
      document.body.appendChild(script);
    } catch {
      // Safe local demo mode: no false claim of a real payment.
      const demo = {
        ...booking,
        status: "Demo payment confirmed",
        paymentId: `DEMO-${Date.now()}`
      };
      setBooking(demo);
      localStorage.setItem("ts_booking", JSON.stringify(demo));
      go("confirmation");
    }
  }

  function downloadReceipt() {
    if (!booking) return;
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text("TRADITIONAL STAY", 20, 25);
    doc.setFontSize(11);
    doc.text("Booking Receipt", 20, 34);
    doc.line(20, 40, 190, 40);

    const rows = [
      ["Booking ID", booking.id],
      ["Guest", booking.guest.name],
      ["Email", booking.guest.email],
      ["Phone", booking.guest.phone],
      ["Room", booking.room],
      ["Check-in", booking.checkIn],
      ["Check-out", booking.checkOut],
      ["Guests", String(booking.guests)],
      ["Room amount", money(booking.roomAmount)],
      ["Taxes & fees", money(booking.taxes)],
      ["Total", money(booking.total)],
      ["Payment status", booking.status],
      ["Payment ID", booking.paymentId || "Not available"]
    ];

    let y = 52;
    for (const [label, value] of rows) {
      doc.setFont("helvetica", "bold");
      doc.text(`${label}:`, 20, y);
      doc.setFont("helvetica", "normal");
      doc.text(String(value), 70, y);
      y += 9;
    }

    y += 4;
    doc.setFont("helvetica", "bold");
    doc.text("Property", 20, y);
    doc.setFont("helvetica", "normal");
    y += 8;
    const lines = doc.splitTextToSize(PROPERTY.address, 165);
    doc.text(lines, 20, y);

    doc.save(`${booking.id}-receipt.pdf`);
  }

  return (
    <div className="app">
      <header className="nav">
        <button className="brand" onClick={() => go("home")}>
          <span className="brandMark">TS</span>
          <span>
            <strong>Traditional Stay</strong>
            <small>SPOT ON • Gandimaisamma</small>
          </span>
        </button>
        <nav>
          <button onClick={() => go("home")}>Home</button>
          <button onClick={() => go("rooms")}>Rooms</button>
          <button onClick={() => go("amenities")}>Amenities</button>
          <button onClick={() => go("reviews")}>Reviews</button>
          <button onClick={() => go("location")}>Location</button>
          {auth ? (
            <button className="pill" onClick={() => go("account")}>Account</button>
          ) : (
            <button className="pill" onClick={() => go("auth")}>Register / Login</button>
          )}
        </nav>
      </header>

      <main>
        {page === "home" && (
          <>
            <section className="hero">
              <div className="heroText">
                <span className="eyebrow">DIRECT BOOKING</span>
                <h1>Stay simple.<br /><span>Book directly.</span></h1>
                <p>
                  A direct booking experience for SPOT ON Traditional Stay,
                  Gandimaisamma, Hyderabad.
                </p>
                <div className="ratingLine">
                  <b>★ {PROPERTY.rating}</b>
                  <span>{PROPERTY.ratingCount} ratings on the current OYO snapshot</span>
                </div>
                <div className="heroActions">
                  <button className="primary" onClick={() => go("rooms")}>View rooms</button>
                  <button className="secondary" onClick={() => go("location")}>Get directions</button>
                </div>
              </div>
              <div className="heroCard">
                <div className="photoMock">
                  <div className="photoOverlay">
                    <span>HYDERABAD</span>
                    <b>Traditional Stay</b>
                  </div>
                </div>
                <div className="miniInfo">
                  <span>2-star property</span>
                  <span>AC rooms</span>
                  <span>Free Wi-Fi</span>
                </div>
              </div>
            </section>

            <section className="bookingBar">
              <div>
                <label>CHECK-IN</label>
                <input type="date" value={search.checkIn} onChange={e => setSearch({...search, checkIn: e.target.value})} />
              </div>
              <div>
                <label>CHECK-OUT</label>
                <input type="date" value={search.checkOut} onChange={e => setSearch({...search, checkOut: e.target.value})} />
              </div>
              <div>
                <label>GUESTS</label>
                <select value={search.guests} onChange={e => setSearch({...search, guests: e.target.value})}>
                  <option value="1">1 guest</option>
                  <option value="2">2 guests</option>
                  <option value="3">3 guests</option>
                </select>
              </div>
              <button className="primary" onClick={openBooking}>Check availability</button>
            </section>

            <section className="section">
              <div className="sectionHead">
                <div><span className="eyebrow">THE PROPERTY</span><h2>Everything you need for a straightforward stay.</h2></div>
                <button className="textButton" onClick={() => go("amenities")}>Explore amenities →</button>
              </div>
              <div className="featureGrid">
                {PROPERTY.amenities.slice(0, 6).map((a, i) => (
                  <div className="feature" key={a}><span className="icon">{["⌁","◉","▣","◌","▰","□"][i]}</span><b>{a}</b><small>Available at the property</small></div>
                ))}
              </div>
            </section>

            <section className="darkSection">
              <div><span className="eyebrow">LOCATION</span><h2>Gandimaisamma, Hyderabad</h2><p>{PROPERTY.address}</p></div>
              <button className="lightButton" onClick={() => go("location")}>Open location</button>
            </section>
          </>
        )}

        {page === "rooms" && (
          <section className="pageSection">
            <span className="eyebrow">ROOMS</span>
            <h1>Classic Room</h1>
            <div className="roomLayout">
              <div className="roomVisual"><div><span>97 SQ.FT</span><b>Classic</b></div></div>
              <div className="roomDetails">
                <div className="price">{money(PROPERTY.room.price)} <small>room/night</small></div>
                <p>Maximum {PROPERTY.room.capacity} guests • {PROPERTY.room.size} • {PROPERTY.room.bed}</p>
                <div className="tagList">{PROPERTY.room.features.map(x => <span key={x}>{x}</span>)}</div>
                <button className="primary wide" onClick={() => go("book")}>Book this room</button>
              </div>
            </div>
          </section>
        )}

        {page === "amenities" && (
          <section className="pageSection">
            <span className="eyebrow">AMENITIES</span>
            <h1>Property facilities</h1>
            <div className="amenityList">{PROPERTY.amenities.map(x => <div className="amenityRow" key={x}><span>✓</span><b>{x}</b></div>)}</div>
            <div className="policyBox"><b>Check-in</b><span>{PROPERTY.checkIn}</span><b>Check-out</b><span>{PROPERTY.checkOut}</span></div>
          </section>
        )}

        {page === "reviews" && (
          <section className="pageSection">
            <span className="eyebrow">REVIEWS</span>
            <h1>Guest feedback</h1>
            <div className="reviewNotice">Ratings can change across booking platforms and over time. The cards below distinguish the source and do not invent individual review text.</div>
            <div className="reviewsGrid">
              {seedReviews.map((r, i) => (
                <article className="reviewCard" key={i}>
                  <div className="reviewTop"><b>{r.source}</b>{r.rating && <span>★ {r.rating}</span>}</div>
                  <p>{r.text}</p><small>{r.note}</small>
                </article>
              ))}
            </div>
          </section>
        )}

        {page === "location" && (
          <section className="pageSection">
            <span className="eyebrow">LOCATION</span>
            <h1>Find Traditional Stay</h1>
            <p className="lead">{PROPERTY.address}</p>
            <p>Landmark: {PROPERTY.landmark}</p>
            <div className="mapBox">
              <iframe
                title="Traditional Stay location"
                src={`https://www.google.com/maps?q=${PROPERTY.coords.lat},${PROPERTY.coords.lng}&z=16&output=embed`}
                loading="lazy"
              />
            </div>
            <a className="primary inlineButton" href="https://www.google.com/maps/place/SPOT+ON+by+OYO+Traditional+Stay/@17.5748351,78.4183923,17z" target="_blank" rel="noreferrer">Open Google Maps</a>
          </section>
        )}

        {page === "auth" && (
          <section className="authPage">
            <form className="authCard" onSubmit={saveUser}>
              <span className="eyebrow">{authMode === "register" ? "CREATE ACCOUNT" : "LOGIN"}</span>
              <h1>{authMode === "register" ? "Create your guest account" : "Guest login"}</h1>
              {authMode === "register" && <input placeholder="Full name" value={form.name} onChange={e => setForm({...form,name:e.target.value})} />}
              <input type="email" placeholder="Email" value={form.email} onChange={e => setForm({...form,email:e.target.value})} />
              <input placeholder="Phone number" value={form.phone} onChange={e => setForm({...form,phone:e.target.value})} />
              <input type="password" placeholder="Password" value={form.password} onChange={e => setForm({...form,password:e.target.value})} />
              <button className="primary wide">{authMode === "register" ? "Create account" : "Login"}</button>
              <button type="button" className="textButton" onClick={() => setAuthMode(authMode === "register" ? "login" : "register")}>
                Switch to {authMode === "register" ? "login" : "registration"}
              </button>
            </form>
          </section>
        )}

        {page === "account" && (
          <section className="pageSection">
            <span className="eyebrow">ACCOUNT</span>
            <h1>{localStorage.getItem("ts_user_name") || "Guest"}</h1>
            <p>{auth}</p>
            {booking && <div className="bookingSummary"><b>{booking.id}</b><span>{booking.room}</span><span>{booking.checkIn} → {booking.checkOut}</span><strong>{booking.status}</strong></div>}
            <button className="secondary" onClick={() => { localStorage.removeItem("ts_user"); setAuth(""); go("home"); }}>Logout</button>
          </section>
        )}

        {page === "book" && (
          <section className="pageSection">
            <span className="eyebrow">BOOKING</span>
            <h1>Reserve your room</h1>
            <div className="checkoutGrid">
              <form className="checkoutForm" onSubmit={createBooking}>
                <input placeholder="Guest full name" value={guestForm.name} onChange={e => setGuestForm({...guestForm,name:e.target.value})} />
                <input type="email" placeholder="Email" value={guestForm.email} onChange={e => setGuestForm({...guestForm,email:e.target.value})} />
                <input placeholder="Phone" value={guestForm.phone} onChange={e => setGuestForm({...guestForm,phone:e.target.value})} />
                <select value={guestForm.guests} onChange={e => setGuestForm({...guestForm,guests:e.target.value})}>
                  <option value="1">1 guest</option><option value="2">2 guests</option><option value="3">3 guests</option>
                </select>
                <button className="primary wide">Continue to payment</button>
              </form>
              <div className="summaryCard">
                <b>{PROPERTY.room.name}</b>
                <span>{search.checkIn || "Select date"} → {search.checkOut || "Select date"}</span>
                <hr />
                <div><span>Room</span><b>{money(PROPERTY.room.price)}</b></div>
                <div><span>Taxes & fees</span><b>{money(PROPERTY.room.tax)}</b></div>
                <div className="total"><span>Total</span><b>{money(total)}</b></div>
              </div>
            </div>
          </section>
        )}

        {page === "payment" && (
          <section className="pageSection">
            <span className="eyebrow">PAYMENT</span>
            <h1>Secure checkout</h1>
            <div className="paymentCard">
              <div><span>Booking</span><b>{booking?.id}</b></div>
              <div><span>Guest</span><b>{booking?.guest.name}</b></div>
              <div><span>Total</span><strong>{money(booking?.total || total)}</strong></div>
              <p>Production payments use Razorpay Checkout when the server keys are configured. Without keys, the project uses an explicitly labelled demo payment path.</p>
              <button className="primary wide" onClick={pay}>Pay {money(booking?.total || total)}</button>
            </div>
          </section>
        )}

        {page === "confirmation" && (
          <section className="successPage">
            <div className="successIcon">✓</div>
            <span className="eyebrow">BOOKING CONFIRMED</span>
            <h1>Your reservation is recorded.</h1>
            <p>Booking ID: <b>{booking?.id}</b></p>
            <div className="receiptPreview">
              <div><span>Property</span><b>{PROPERTY.name}</b></div>
              <div><span>Room</span><b>{booking?.room}</b></div>
              <div><span>Dates</span><b>{booking?.checkIn} → {booking?.checkOut}</b></div>
              <div><span>Amount</span><b>{money(booking?.total)}</b></div>
              <div><span>Status</span><b>{booking?.status}</b></div>
            </div>
            <button className="primary" onClick={downloadReceipt}>Download receipt PDF</button>
            <button className="secondary" onClick={() => go("home")}>Back to home</button>
          </section>
        )}
      </main>

      <footer>
        <div><b>Traditional Stay</b><p>SPOT ON by OYO Traditional Stay</p></div>
        <div><span>{PROPERTY.address}</span><a href="https://www.google.com/maps/place/SPOT+ON+by+OYO+Traditional+Stay/@17.5748351,78.4183923,17z" target="_blank" rel="noreferrer">Maps ↗</a></div>
        <small>Independent direct-booking interface. OYO trademarks and third-party review content remain the property of their respective owners.</small>
      </footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);