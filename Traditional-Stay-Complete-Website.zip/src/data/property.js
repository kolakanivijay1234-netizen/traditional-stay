export const property = {
  name: "SPOT ON Traditional Stay",
  address: "Plot no.- 3-178, Road Number 4, Ganesh Nagar, Gandimaisamma, Madchal, Hyderabad, 500043, India",
  landmark: "Near Snak Hub / New Baba Building"
};