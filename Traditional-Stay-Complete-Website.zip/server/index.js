import express from "express";
import cors from "cors";
import crypto from "crypto";
import Razorpay from "razorpay";
import "dotenv/config";

const app = express();
app.use(cors());
app.use(express.json());

const port = process.env.PORT || 5000;
const razorpay =
  process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET
    ? new Razorpay({
        key_id: process.env.RAZORPAY_KEY_ID,
        key_secret: process.env.RAZORPAY_KEY_SECRET
      })
    : null;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, paymentsConfigured: Boolean(razorpay) });
});

app.post("/api/create-order", async (req, res) => {
  try {
    if (!razorpay) {
      return res.status(503).json({
        error: "Razorpay is not configured. Add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET to .env."
      });
    }

    const { amount, bookingId } = req.body;
    if (!Number.isFinite(amount) || amount < 1) {
      return res.status(400).json({ error: "Invalid amount." });
    }

    const order = await razorpay.orders.create({
      amount: Math.round(amount * 100),
      currency: "INR",
      receipt: String(bookingId || `TS-${Date.now()}`).slice(0, 40)
    });

    res.json(order);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/verify-payment", (req, res) => {
  const {
    razorpay_order_id,
    razorpay_payment_id,
    razorpay_signature
  } = req.body;

  if (!process.env.RAZORPAY_KEY_SECRET) {
    return res.status(503).json({ error: "Payment verification is not configured." });
  }

  const expected = crypto
    .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest("hex");

  const valid = crypto.timingSafeEqual(
    Buffer.from(expected),
    Buffer.from(razorpay_signature || "")
  );

  res.json({ valid });
});

app.listen(port, () => {
  console.log(`Traditional Stay payment server running on http://localhost:${port}`);
});