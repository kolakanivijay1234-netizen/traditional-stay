# Traditional Stay — Direct Booking Website

A complete React/Vite website for **SPOT ON Traditional Stay, Gandimaisamma, Hyderabad**.

## Verified property information used

- Property: SPOT ON Traditional Stay
- Address: Plot no.- 3-178, Road Number 4, Ganesh Nagar, Gandimaisamma, Madchal, Hyderabad, 500043
- Landmark: Near Snak Hub / New Baba Building
- Property category: 2-star budget hotel
- Classic room: 97 sq.ft (9 sq.mt), 1 Queen Bed, maximum 3 guests
- Facilities represented in public listings: AC, Wi-Fi, TV, private bathroom, room service, housekeeping, mineral water, family rooms, 24-hour front desk
- Check-in: 12:00 PM
- Check-out: 11:00 AM
- Public listing prices vary by date, platform, discounts and taxes. The starter price in this demo is editable in `src/main.jsx`.

## Run in VS Code

```bash
npm install
npm run dev
```

Open the Vite URL shown in the terminal, normally:

http://localhost:5173

## Payment

The project supports a real Razorpay Checkout integration, but a real payment gateway must be configured by the property owner.

1. Create `.env` from `.env.example`.
2. Put the Razorpay test/live keys on the server.
3. Start the payment server:

```bash
npm run server
```

4. In another terminal:

```bash
npm run dev
```

5. Set:

```env
VITE_API_BASE=http://localhost:5000
VITE_RAZORPAY_KEY_ID=rzp_test_xxxxx
```

Do not expose `RAZORPAY_KEY_SECRET` in frontend code.

If the payment server is not configured, the UI uses an explicitly labelled **Demo payment** path. It does not pretend that a real bank/card transaction happened.

## Important production work

This starter is a functional frontend + payment integration prototype. For a real hotel operation, add:

- A real database (PostgreSQL/MySQL/Firebase)
- Server-side room inventory and availability locking
- Authentication with hashed passwords / OAuth
- Razorpay webhook handling and reconciliation
- Cancellation/refund rules
- GST/tax configuration based on the property's actual billing requirements
- Admin dashboard for rooms, prices, bookings and check-ins
- Email/SMS/WhatsApp booking confirmations
- Rate calendar and multiple room types
- Server-side PDF receipts/invoices
- HTTPS and secure deployment

## Reviews and third-party content

The supplied Google Maps short URL redirects to the property's Google Maps listing, but the complete live review feed could not be reliably extracted through the available public page interface. Therefore this project does **not** invent or bulk-copy review text. The UI identifies rating snapshots and their sources instead.

Likewise, OYO/Google/Booking.com images and trademarks should only be used according to the rights/terms applicable to the property owner. Replace the visual placeholders with photos you are authorized to publish.

## Production deployment

Frontend can be deployed to Vercel/Netlify/Cloudflare Pages.
The Express payment server must be deployed separately and given the server-side Razorpay secret.

